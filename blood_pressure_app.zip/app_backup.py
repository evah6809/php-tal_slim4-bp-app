import os
import json
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, session, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'your-super-secret-key') 

# ==========================================
# 🔑 PostgreSQL 接続設定
# ==========================================
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://shin_user:shinpass@localhost/blood_pressure_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# ==========================================
# 📐 データベースの設計図（モデル）
# ==========================================
class BloodPressureRecord(db.Model):
    __tablename__ = 'blood_pressure_records'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), nullable=False)   # 利用者の識別ID
    date = db.Column(db.String(10), nullable=False)      # YYYY-MM-DD
    timing = db.Column(db.String(10), nullable=False)    # 'morning' or 'evening'
    weight = db.Column(db.Float)                         
    systolic1 = db.Column(db.Integer)
    diastolic1 = db.Column(db.Integer)
    pulse1 = db.Column(db.Integer)
    systolic2 = db.Column(db.Integer)
    diastolic2 = db.Column(db.Integer)
    pulse2 = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

# 起動時にテーブルを作成
with app.app_context():
    db.create_all()

# ==========================================
# ⚙️ 便利関数
# ==========================================
def is_logged_in():
    return 'user_id' in session

def calc_avg(val1, val2):
    if val1 is not None and val2 is not None:
        return round((val1 + val2) / 2)
    elif val1 is not None:
        return val1
    elif val2 is not None:
        return val2
    return None

# ==========================================
# 🚀 ルート処理
# ==========================================

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        data = request.json
        session['user_id'] = data.get('uid')
        session['name'] = data.get('name')
        session['email'] = data.get('email')
        return jsonify({
            'status': 'success',
            'redirect_url': url_for('index')
        })
    if is_logged_in():
        return redirect(url_for('index'))
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/', methods=['GET', 'POST'])
def index():
    if not is_logged_in():
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    today_str = datetime.now().strftime('%Y-%m-%d')

    if request.method == 'POST':
        date = request.form.get('date') if request.form.get('date') else today_str
        weight = float(request.form.get('weight')) if request.form.get('weight') else None

        form_data = {
            'morning': {
                'systolic1': int(request.form.get('m_systolic1')) if request.form.get('m_systolic1') else None,
                'diastolic1': int(request.form.get('m_diastolic1')) if request.form.get('m_diastolic1') else None,
                'pulse1': int(request.form.get('m_pulse1')) if request.form.get('m_pulse1') else None,
                'systolic2': int(request.form.get('m_systolic2')) if request.form.get('m_systolic2') else None,
                'diastolic2': int(request.form.get('m_diastolic2')) if request.form.get('m_diastolic2') else None,
                'pulse2': int(request.form.get('m_pulse2')) if request.form.get('m_pulse2') else None,
            },
            'evening': {
                'systolic1': int(request.form.get('e_systolic1')) if request.form.get('e_systolic1') else None,
                'diastolic1': int(request.form.get('e_diastolic1')) if request.form.get('e_diastolic1') else None,
                'pulse1': int(request.form.get('e_pulse1')) if request.form.get('e_pulse1') else None,
                'systolic2': int(request.form.get('e_systolic2')) if request.form.get('e_systolic2') else None,
                'diastolic2': int(request.form.get('e_diastolic2')) if request.form.get('e_diastolic2') else None,
                'pulse2': int(request.form.get('e_pulse2')) if request.form.get('e_pulse2') else None,
            }
        }

        for timing, dataset in form_data.items():
            has_data = any(v is not None for v in dataset.values())
            record = BloodPressureRecord.query.filter_by(user_id=user_id, date=date, timing=timing).first()

            if record:
                record.weight = weight
                for key, val in dataset.items():
                    setattr(record, key, val)
            elif has_data or weight is not None:
                new_record = BloodPressureRecord(user_id=user_id, date=date, timing=timing, weight=weight)
                for key, val in dataset.items():
                    setattr(new_record, key, val)
                db.session.add(new_record)

        db.session.commit()
        return redirect(url_for('history'))

    # 本日の記録サマリー
    today_records = []
    records = BloodPressureRecord.query.filter_by(user_id=user_id, date=today_str).all()
    for r in records:
        if r.systolic1 is not None or r.systolic2 is not None or r.weight is not None:
            today_records.append({
                'timing_display': '朝' if r.timing == 'morning' else '夜',
                'systolic1': r.systolic1, 'systolic2': r.systolic2,
                'diastolic1': r.diastolic1, 'diastolic2': r.diastolic2,
                'avg_sys': calc_avg(r.systolic1, r.systolic2),
                'avg_dia': calc_avg(r.diastolic1, r.diastolic2)
            })

    # ⭕【絶対安全設計】JSONファイルの絶対パスを取得して確実に読み込む
    announcements = []
    # app.py が置いてある場所を基準にして json ファイルの正確な位置を割り出します
    current_dir = os.path.dirname(os.path.abspath(__file__))
    json_path = os.path.join(current_dir, 'announcements.json')

    if os.path.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                announcements = json.load(f)
        except Exception as e:
            print("JSON読み込みエラー:", e)
            # 読み込みに失敗した場合は空のリストを維持して画面クラッシュを防ぐ
            announcements = []

    return render_template('index.html', name=session['name'], announcements=announcements, today_records=today_records, today_str=today_str)


@app.route('/get_record', methods=['GET'])
def get_record():
    if not is_logged_in():
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    
    user_id = session['user_id']
    date = request.args.get('date')

    records = BloodPressureRecord.query.filter_by(user_id=user_id, date=date).all()
    result = {'morning': None, 'evening': None, 'weight': None}

    for r in records:
        if r.weight is not None:
            result['weight'] = r.weight

        if any(v is not None for v in [r.systolic1, r.diastolic1, r.pulse1, r.systolic2, r.diastolic2, r.pulse2]):
            record_data = {
                'systolic1': r.systolic1, 'diastolic1': r.diastolic1, 'pulse1': r.pulse1,
                'systolic2': r.systolic2, 'diastolic2': r.diastolic2, 'pulse2': r.pulse2
            }
            if r.timing == 'morning': result['morning'] = record_data
            elif r.timing == 'evening': result['evening'] = record_data

    return jsonify({'status': 'success', 'data': result})


@app.route('/history', methods=['GET'])
def history():
    if not is_logged_in():
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    records = BloodPressureRecord.query.filter_by(user_id=user_id).order_by(BloodPressureRecord.date.desc()).all()
    
    grouped_records = {}
    for r in records:
        if r.date not in grouped_records:
            grouped_records[r.date] = {'date': r.date, 'weight': None, 'morning': None, 'evening': None}
            
        if r.weight is not None:
            grouped_records[r.date]['weight'] = r.weight
            
        if any(v is not None for v in [r.systolic1, r.diastolic1, r.pulse1, r.systolic2, r.diastolic2, r.pulse2]):
            record_data = {
                'id': r.id, 
                'sys1': r.systolic1, 'dia1': r.diastolic1, 'pulse1': r.pulse1,
                'sys2': r.systolic2, 'dia2': r.diastolic2, 'pulse2': r.pulse2,
                'avg_sys': calc_avg(r.systolic1, r.systolic2),
                'avg_dia': calc_avg(r.diastolic1, r.diastolic2),
                'avg_pulse': calc_avg(r.pulse1, r.pulse2)
            }
            if r.timing == 'morning': grouped_records[r.date]['morning'] = record_data
            elif r.timing == 'evening': grouped_records[r.date]['evening'] = record_data
            
    history_data = [grouped_records[date] for date in sorted(grouped_records.keys(), reverse=True)]
    return render_template('history.html', records=history_data)


@app.route('/history/delete/<int:record_id>', methods=['POST'])
def delete_record(record_id):
    if not is_logged_in():
        return redirect(url_for('login'))
    
    record = BloodPressureRecord.query.get_or_404(record_id)
    db.session.delete(record)
    db.session.commit()
    return redirect(url_for('history'))

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)
