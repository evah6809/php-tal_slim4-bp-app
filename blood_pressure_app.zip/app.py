import os
import json
import requests
from google import genai
from dotenv import load_dotenv
from datetime import datetime, timedelta
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from authlib.integrations.flask_client import OAuth

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'your-super-secret-key') 

load_dotenv()
ai_client = genai.Client()

# ==========================================
# 🔑 Googleログイン設定
# ==========================================
oauth = OAuth(app)
google = oauth.register(
    name='google',
    client_id=os.environ.get('GOOGLE_CLIENT_ID'),
    client_secret=os.environ.get('GOOGLE_CLIENT_SECRET'),
    access_token_url='https://oauth2.googleapis.com/token',
    access_token_params=None,
    authorize_url='https://accounts.google.com/o/oauth2/auth',
    authorize_params={'prompt': 'select_account'},
    api_base_url='https://www.googleapis.com/oauth2/v1/',
    userinfo_endpoint='https://openidconnect.googleapis.com/v1/userinfo',
    client_kwargs={'scope': 'openid email profile'},
    server_metadata_url='https://accounts.google.com/.well-known/openid-configuration'
)

# ==========================================
# 🔑 PostgreSQL 接続設定
# ==========================================
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# ==========================================
# 📐 データベースの設計図（モデル）
# ==========================================
class BloodPressureRecord(db.Model):
    __tablename__ = 'blood_pressure_records'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.String(100), nullable=False)   # 利用者の識別ID (Googleの独自ID)
    date = db.Column(db.String(10), nullable=False)      # YYYY-MM-DD
    timing = db.Column(db.String(10), nullable=False)    # 'morning' or 'evening'
    weight = db.Column(db.Float)                         
    systolic1 = db.Column(db.Integer)
    diastolic1 = db.Column(db.Integer)
    pulse1 = db.Column(db.Integer)
    systolic2 = db.Column(db.Integer)
    diastolic2 = db.Column(db.Integer)
    pulse2 = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

with app.app_context():
    db.create_all()

# ==========================================
# ⚙️ 便利関数
# ==========================================
def is_logged_in():
    return 'user_id' in session

def calc_avg(val1, val2):
    if val1 is not None and val2 is not None:
        return round((val1 + val2) / 2)
    elif val1 is not None:
        return val1
    elif val2 is not None:
        return val2
    return None

# --- 💡 PWA用のルーティング追加 ---
@app.route('/manifest.json')
def serve_manifest():
    return send_from_directory('.', 'manifest.json', mimetype='application/json')

@app.route('/sw.js')
def serve_sw():
    return app.send_static_file('sw.js')

# --- 📢 ゴミ出し自動判定ロジック ---
def get_trash_announcement():
    today = datetime.now().date()
    tomorrow = today + timedelta(days=1)
    day_after_tomorrow = today + timedelta(days=2)
    
    WEEK_NAMES = ["月", "火", "水", "木", "金", "土", "日"]
    messages = []
    
    for target_date, label in [(today, "本日"), (tomorrow, "明日"), (day_after_tomorrow, "あさって")]:
        w_num = target_date.weekday()
        w_name = WEEK_NAMES[w_num]
        nth_week = (target_date.day - 1) // 7 + 1
        
        todays_trash = []
        
        if w_num == 0 or w_num == 3:
            todays_trash.append("燃やせるゴミ（赤袋）")
        
        if w_num == 1:
            if nth_week == 1 or nth_week == 3:
                todays_trash.append("ペットボトル（透明袋）")
            elif nth_week == 2 or nth_week == 4:
                todays_trash.append("空き缶・空きびん（透明袋）")
                
        if w_num == 2:
            if nth_week == 1:
                todays_trash.append("もやせないゴミ（青袋）")
                todays_trash.append("金属類（透明袋）")
            elif nth_week == 3:
                todays_trash.append("その他の資源ごみ")
                
        if w_num == 4:
            todays_trash.append("プラごみ（透明袋）")
            if nth_week <= 4:
                todays_trash.append("古紙・古布（紐縛り）")

        if todays_trash:
            trash_str = "と".join(todays_trash)
            msg = f"{label}{target_date.strftime('%m/%d')}({w_name})は 【{trash_str}】"
            messages.append(msg)
            
    return messages

# --- 🌤 お天気自動取得ロジック ---
def get_weather_forecast():
    try:
        url = "https://www.jma.go.jp/bosai/forecast/data/forecast/450000.json"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
        response = requests.get(url, headers=headers, timeout=5)
        
        if response.status_code == 200:
            data = response.json()
            area_data = None
            for report in data:
                for time_series in report.get('timeSeries', []):
                    for area in time_series.get('areas', []):
                        if area.get('area', {}).get('code') == '450010' and 'weathers' in area:
                            area_data = area
                            break
            
            if area_data:
                today_weather = area_data['weathers'][0]
                tomorrow_weather = area_data['weathers'][1]
                clean_today = today_weather.replace(' ', ' ').split(' ')[0]
                clean_tomorrow = tomorrow_weather.replace(' ', ' ').split(' ')[0]
                return {'today': clean_today, 'tomorrow': clean_tomorrow}
    except Exception as e:
        print("天気予報の取得に失敗しました:", e)
        
    return {'today': "情報なし", 'tomorrow': "情報なし"}

# ==========================================
# 🚀 ルート処理
# ==========================================

@app.route('/login')
def login():
    if is_logged_in():
        return redirect(url_for('index'))
    return render_template('login.html')

@app.route('/login/google')
def login_google():
    return google.authorize_redirect(
        redirect_uri=url_for('google_authorize', _external=True)
    )

@app.route('/login/authorize')
def google_authorize():
    token = google.authorize_access_token()
    resp = google.get('userinfo')
    user_info = resp.json()
    
    session['user_id'] = user_info['id']
    session['name'] = user_info['name']
    session['email'] = user_info['email']
    
    return redirect(url_for('index'))

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/', methods=['GET', 'POST'])
def index():
    if not is_logged_in():
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    today_str = datetime.now().strftime('%Y-%m-%d')

    if request.method == 'POST':
        date = request.form.get('date') if request.form.get('date') else today_str
        weight = float(request.form.get('weight')) if request.form.get('weight') else None

        form_data = {
            'morning': {
                'systolic1': int(request.form.get('m_systolic1')) if request.form.get('m_systolic1') else None,
                'diastolic1': int(request.form.get('m_diastolic1')) if request.form.get('m_diastolic1') else None,
                'pulse1': int(request.form.get('m_pulse1')) if request.form.get('m_pulse1') else None,
                'systolic2': int(request.form.get('m_systolic2')) if request.form.get('m_systolic2') else None,
                'diastolic2': int(request.form.get('m_diastolic2')) if request.form.get('m_diastolic2') else None,
                'pulse2': int(request.form.get('m_pulse2')) if request.form.get('m_pulse2') else None,
            },
            'evening': {
                'systolic1': int(request.form.get('e_systolic1')) if request.form.get('e_systolic1') else None,
                'diastolic1': int(request.form.get('e_diastolic1')) if request.form.get('e_diastolic1') else None,
                'pulse1': int(request.form.get('e_pulse1')) if request.form.get('e_pulse1') else None,
                'systolic2': int(request.form.get('e_systolic2')) if request.form.get('e_systolic2') else None,
                'diastolic2': int(request.form.get('e_diastolic2')) if request.form.get('e_diastolic2') else None,
                'pulse2': int(request.form.get('e_pulse2')) if request.form.get('e_pulse2') else None,
            }
        }

        for timing, dataset in form_data.items():
            has_data = any(v is not None for v in dataset.values())
            record = BloodPressureRecord.query.filter_by(user_id=user_id, date=date, timing=timing).first()

            if record:
                record.weight = weight
                for key, val in dataset.items():
                    setattr(record, key, val)
            elif has_data or weight is not None:
                new_record = BloodPressureRecord(user_id=user_id, date=date, timing=timing, weight=weight)
                for key, val in dataset.items():
                    setattr(new_record, key, val)
                db.session.add(new_record)

        db.session.commit()
        return redirect(url_for('history'))

    today_records = []
    records = BloodPressureRecord.query.filter_by(user_id=user_id, date=today_str).all()
    for r in records:
        if r.systolic1 is not None or r.systolic2 is not None or r.weight is not None:
            today_records.append({
                'timing_display': '朝' if r.timing == 'morning' else '夜',
                'systolic1': r.systolic1, 'systolic2': r.systolic2,
                'diastolic1': r.diastolic1, 'diastolic2': r.diastolic2,
                'avg_sys': calc_avg(r.systolic1, r.systolic2),
                'avg_dia': calc_avg(r.diastolic1, r.diastolic2)
            })

    announcements = []
    current_dir = os.path.dirname(os.path.abspath(__file__))
    json_path = os.path.join(current_dir, 'announcements.json')

    if os.path.exists(json_path):
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                announcements = json.load(f)
        except Exception as e:
            print("JSON読み込みエラー:", e)
            announcements = []

    trash_alerts = get_trash_announcement()
    weather = get_weather_forecast()
    
    return render_template('index.html', name=session['name'], announcements=announcements, today_records=today_records, today_str=today_str, trash_alerts=trash_alerts, weather=weather)

@app.route('/get_record', methods=['GET'])
def get_record():
    if not is_logged_in():
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    
    user_id = session['user_id']
    date = request.args.get('date')

    records = BloodPressureRecord.query.filter_by(user_id=user_id, date=date).all()
    result = {'morning': None, 'evening': None, 'weight': None}

    for r in records:
        if r.weight is not None:
            result['weight'] = r.weight

        if any(v is not None for v in [r.systolic1, r.diastolic1, r.pulse1, r.systolic2, r.diastolic2, r.pulse2]):
            record_data = {
                'systolic1': r.systolic1, 'diastolic1': r.diastolic1, 'pulse1': r.pulse1,
                'systolic2': r.systolic2, 'diastolic2': r.diastolic2, 'pulse2': r.pulse2
            }
            if r.timing == 'morning': result['morning'] = record_data
            elif r.timing == 'evening': result['evening'] = record_data

    return jsonify({'status': 'success', 'data': result})

@app.route('/history', methods=['GET'])
def history():
    if not is_logged_in():
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    
    # 💡 URLから選ばれた月を取得（デフォルトは現在の月）
    current_month_str = datetime.now().strftime('%m')
    selected_month = request.args.get('month', current_month_str)
    
    records = BloodPressureRecord.query.filter_by(user_id=user_id).order_by(BloodPressureRecord.date.desc()).all()
    
    grouped_records = {}
    for r in records:
        try:
            record_month = r.date.split('-')[1]
        except IndexError:
            continue
            
        # 💡 選択された月以外のデータはスキップ（月別絞り込み）
        if record_month != selected_month:
            continue
            
        if r.date not in grouped_records:
            grouped_records[r.date] = {'date': r.date, 'weight': None, 'morning': None, 'evening': None}
            
        if r.weight is not None:
            grouped_records[r.date]['weight'] = r.weight
            
        if any(v is not None for v in [r.systolic1, r.diastolic1, r.pulse1, r.systolic2, r.diastolic2, r.pulse2]):
            record_data = {
                'id': r.id, 
                'sys1': r.systolic1, 'dia1': r.diastolic1, 'pulse1': r.pulse1,
                'sys2': r.systolic2, 'dia2': r.diastolic2, 'pulse2': r.pulse2,
                'avg_sys': calc_avg(r.systolic1, r.systolic2),
                'avg_dia': calc_avg(r.diastolic1, r.diastolic2),
                'avg_pulse': calc_avg(r.pulse1, r.pulse2)
            }
            if r.timing == 'morning': grouped_records[r.date]['morning'] = record_data
            elif r.timing == 'evening': grouped_records[r.date]['evening'] = record_data
            
    final_records = [grouped_records[date] for date in sorted(grouped_records.keys(), reverse=True)]
    return render_template('history.html', records=final_records, selected_month=int(selected_month))

@app.route('/history/delete/<int:record_id>', methods=['POST'])
def delete_record(record_id):
    if not is_logged_in():
        return redirect(url_for('login'))
    
    record = BloodPressureRecord.query.get_or_404(record_id)
    db.session.delete(record)
    db.session.commit()
    return redirect(url_for('history'))

@app.route('/print_handbook', methods=['GET'])
def print_handbook():
    if not is_logged_in():
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    
    # URLの「?month=07」から月を取得（なければ現在の月）
    current_month_str = datetime.now().strftime('%m')
    selected_month = request.args.get('month', current_month_str)
    
    # 1. ログイン中のユーザーの全データを取得
    records = BloodPressureRecord.query.filter_by(user_id=user_id).order_by(BloodPressureRecord.date.asc()).all()
    
    # 2. 選択された月のデータだけを朝夜合体させてまとめる
    grouped_records = {}
    for r in records:
        try:
            record_month = r.date.split('-')[1]
        except IndexError:
            continue
            
        if record_month != selected_month:
            continue
            
        if r.date not in grouped_records:
            grouped_records[r.date] = {'date': r.date, 'weight': None, 'morning': None, 'evening': None}
            
        if r.weight is not None:
            grouped_records[r.date]['weight'] = r.weight
            
        if any(v is not None for v in [r.systolic1, r.diastolic1, r.pulse1, r.systolic2, r.diastolic2, r.pulse2]):
            record_data = {
                'avg_sys': calc_avg(r.systolic1, r.systolic2),
                'avg_dia': calc_avg(r.diastolic1, r.diastolic2),
                'avg_pulse': calc_avg(r.pulse1, r.pulse2)
            }
            if r.timing == 'morning': grouped_records[r.date]['morning'] = record_data
            elif r.timing == 'evening': grouped_records[r.date]['evening'] = record_data
            
    final_records = [grouped_records[date] for date in sorted(grouped_records.keys())]
    
    # 💡 印刷専用のすっきりした画面（print_handbook.html）にデータを送って表示させる
    return render_template('print_handbook.html', records=final_records, selected_month=int(selected_month))


# ==========================================
# 🤖 Gemini AIお助け相談窓口の処理
# ==========================================
@app.route('/ask_gemini', methods=['POST'])
def ask_gemini():
    if not is_logged_in():
        return jsonify({'error': 'ログインが必要です'}), 401
        
    user_question = request.form.get('question', '').strip()
    
    if not user_question:
        return jsonify({'answer': '質問が空っぽのようです。何か入力してくださいね！'})
        
    try:
        system_instruction = (
            "あなたは年配の方向けの健康管理アプリに内蔵された、優しくて親しみやすいAI相談員です。"
            "専門用語は一切使わず、小学生やおじいちゃん・おばあちゃんでも1秒で理解できる言葉だけを使ってください。"
            "回答は必ず「100文字以内」で、パッと読めるように短く要約して答えてください。"
        )
        
        response = ai_client.models.generate_content(
            model='gemini-2.5-flash',
            contents=user_question,
            config={'system_instruction': system_instruction}
        )
        
        return jsonify({'answer': response.text})
        
    except Exception as e:
        print("Geminiの呼び出しに失敗しました:", e)
        return jsonify({'answer': 'ごめんなさい、AI相談員がちょっと席を外しているようです。時間をあけてもう一度聞いてみてください。'})

# ==========================================
# 🛡️ 管理者画面の処理
# ==========================================
@app.route('/admin')
def admin_dashboard():
    all_records = BloodPressureRecord.query.order_by(
        BloodPressureRecord.date.desc(), 
        BloodPressureRecord.created_at.desc()
    ).all()
    
    grouped_data = {}
    for record in all_records:
        key = f"{record.user_id}_{record.date}"
        if key not in grouped_data:
            grouped_data[key] = {
                'user_id': record.user_id,
                'date': record.date,
                'morning': None,
                'evening': None,
                'weight': None
            }
        
        if record.weight:
            grouped_data[key]['weight'] = record.weight
            
        if record.timing == 'morning':
            grouped_data[key]['morning'] = record
        elif record.timing == 'evening':
            grouped_data[key]['evening'] = record

    final_records = sorted(
        grouped_data.values(), 
        key=lambda x: (x['date'], x['user_id']), 
        reverse=True
    )
    
    return render_template('admin.html', records=final_records)

# ==========================================
# 🚨 エラーハンドラー
# ==========================================
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

if __name__ == '__main__':
    is_debug = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    app.run(debug=is_debug, host='127.0.0.1', port=5000)